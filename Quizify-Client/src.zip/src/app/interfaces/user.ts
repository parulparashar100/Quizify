export interface User {
    id: number;
	firstName: string;
	lastName: string;
	dob: string;
	gender: string;
	email: string;
	password: string;
	status: boolean;
	role: string;
}