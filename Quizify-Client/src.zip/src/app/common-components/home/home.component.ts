import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {

  constructor(public _loginService: LoginService, private _router: Router) {}

  startQuiz() {
    if(this._loginService.isLoggedIn())
      // this._router.navigate(['/category']);
      this._router.navigate(['/login']);
    
    else 
      this._router.navigate(['/login']);
    
  }

}
