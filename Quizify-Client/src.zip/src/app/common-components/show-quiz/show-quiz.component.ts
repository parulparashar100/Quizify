import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Quiz } from 'src/app/interfaces/quiz';
import { LoginService } from 'src/app/services/login.service';
import { QuizService } from 'src/app/services/quiz.service';

@Component({
  selector: 'app-show-quiz',
  templateUrl: './show-quiz.component.html',
  styleUrls: ['./show-quiz.component.css']
})
export class ShowQuizComponent {

  quizzes: any;
  isAdmin: boolean;
  isUser: boolean;

  constructor(private _router: Router, private _quizService: QuizService, public _loginService: LoginService) {
    if(this._loginService.getUserRole() === "admin") {
      this.isAdmin = true;
      this.isUser = false;
    } else {
      this.isAdmin = false;
      this.isUser = true;
    }
  }

  ngOnInit(): void {
    this.setIsAdmin();
    this.getAllQuiz();
    console.log(this.isAdmin);
    console.log(this.isUser)
  }

  openQuiz() {

  }

  setIsAdmin() {
    if(this._loginService.getUserRole() === "admin") {
      this.isAdmin = true;
      this.isUser = false;
    } else {
      this.isAdmin = false;
      this.isUser = true;
    }
  }

  getAllQuiz() {
    this._quizService.getAllQuiz().subscribe({
      next: (data)=> {
        this.quizzes = data;
      },
      error: (err)=> {
        console.log(err);
      }
    });
  }

}
